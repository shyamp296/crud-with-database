const Sequelize = require('sequelize')

const sequelize = require('../util/database')

const User = sequelize.define('User',{
    id : {
        type : Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    fname : {
        type : Sequelize.STRING,
        allowNull : false
    },
    lname: {
        type: Sequelize.STRING,
        allowNull: false
    },
    email: {
        type: Sequelize.STRING,
        allowNull: false
    },
    psw : {
        type : Sequelize.STRING,
        allowNull: false
    },
    pswc : {
        type : Sequelize.STRING,
    },
    dte : {
        type : Sequelize.DATEONLY,

    },
    phone : {
        type : Sequelize.TEXT
    },
    blood : {
        type : Sequelize.STRING
    },
    addr : {
        type : Sequelize.TEXT
    }



})

module.exports = User