const express = require('express')

const bodyParser = require('body-parser')
const path = require('path')

const usercontroller = require('./controller/user')
const sequelize = require('./util/database')

const app = express()

app.set('view engine', 'ejs')
app.set('views', 'views')

app.use(bodyParser.urlencoded({ extended: false }))

app.use(express.static(path.join(__dirname, 'public')))

app.get('/', usercontroller.userform)

app.get('/users', usercontroller.Showuser)

app.post('/add-user', usercontroller.adduser )

app.post('/delete/:id', usercontroller.deleteuser)

app.get('/update/:id', usercontroller.getuserid);

app.post("/update-user", usercontroller.updateuser)

sequelize.sync().then(result => {
    app.listen(9000);
}).catch(err => {
    console.log(err);
})