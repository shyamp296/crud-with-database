const { Sequelize } = require('sequelize')

const sequelize = new Sequelize('crud', 'root', 'shyam123', {
    dialect: 'mysql', 
    host: 'localhost'
})

module.exports = sequelize