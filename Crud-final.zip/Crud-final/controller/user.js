const path = require('path')
const User = require('../model/User')


exports.userform = ((req, res, next) => {
    res.render('form', { pageTitle: 'Add-User' })
})

exports.Showuser = (req, res, next) => {
    User.findAll().then(users => {
        res.render('output', {
            pageTitle: 'Users',
            user: users
        })
    })
   
}

exports.adduser = (req, res, next) => {
    const id = req.body.id
    const fname = req.body.fname
    const lname = req.body.lname
    const email = req.body.email
    const psw = req.body.psw
    const pswc = req.body.pswc
    const dte = req.body.dte
    const phone = req.body.phone
    const addr = req.body.addr
    const blood = req.body.blood

    User.create({
        id: id,
        fname: fname,
        lname: lname,
        email: email,
        pswc : pswc,
        psw: psw,
        dte: dte,
        phone: phone,
        addr: addr,
        blood: blood
    }).then(result => {
        console.log(result);
       res.redirect('/users')
    }).catch(err => {
        console.log(err)
    })
}


exports.deleteuser = (req, res) => {
    let id = req.params.id
    console.log(id);
    User.findByPk(id).then(user => {
        return user.destroy()
    }).then(result => {
        res.redirect('/users')
    })
}

exports.getuserid = (req, res) => {
    let id = req.params.id
    User.findByPk(id).then(user => {
        res.render('edit', {
            pageTitle: 'Update',
            User: user,
        })
    }).catch(err => {
        console.log(err);
    })
    
}

exports.updateuser = (req, res, next) => {
    const id = req.body.id
    const fname = req.body.fname
    const lname = req.body.lname
    const email = req.body.email
    const psw = req.body.psw
    const pswc = req.body.pswc
    const dte = req.body.dte
    const phone = req.body.phone
    const addr = req.body.addr
    const blood = req.body.blood

    console.log(fname);
    User.findByPk(id).then(user =>{

        user.fname = fname
        user.lname = lname
        user.email = email
        user.psw = psw
        user.pswc = pswc
        user.dte = dte
        user.phone = phone
        user.addr = addr
        user.blood = blood
        return user.save()
    }).then(result =>{
        console.log(result);
        res.redirect('/users')
    })
    
   
}